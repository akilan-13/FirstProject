const express =require('express');   
const http = require('http'); //for server
const mySql=require('mysql2')
const bcrypt=require('bcryptjs')
const {Server}=require('socket.io'); //server sockect class
const cors=require('cors');  // for cross orign allow
const jwt=require('jsonwebtoken');  // for cross orign allow

const app=express(); 

app.use(cors());
app.use(express.json());

// db connection
const db= mySql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"ai_chatbot",
})

db.connect((err)=>{
    if(err){ 
        console.error('DB Connection Failed..!');
    }else{
        console.log('DB is Connected');
    }
})

const httpServer=http.createServer(app)
// for cross origin
const io= new Server(httpServer,{
    cors:{
        origin:"http://localhost:3000",
        methods:["GET","POST"],
    }
});


//get general seting
app.get('/api/auth/generalData',async(req,res)=>{
    db.query("SELECT * FROM general_settings Limit 1 ", (err, results) => {
        if (err) {
            return res.status(500).json({ error: "Database error", details: err.message });
        } 
        res.json({ success: true, data: results[0] });
    });


})

// sign up
app.post('/api/auth/signup',async(req,res)=>{
    const {username,email ,password}= req.body;
    const hashedPassword=await bcrypt.hash(password,10);

    db.query(
        "INSERT INTO users (username,email,password,text_password) values(?,?,?,?)",
        [username,email,hashedPassword,password], (err)=>{
            if(err){
                return res.status(500).json({error:"user is Already Exists..!"})
            }else{
                res.json({success:true , message:"user is registered"})
            }
        }
    )

})

app.post("/api/auth/login",(req,res)=>{
    const {username,password}=req.body;
    db.query(
        "select * from users where username = ?",[username], async(err,result)=>{
            if(err || result.length===0){
                return res.status(401).json({error:"Invalid Username"})
            }else{
                const user=result[0];
                const passwordMatch=await bcrypt.compare(password,user.password);
                if(!passwordMatch){
                    return res.status(401).json({error:"Invalid Password"})
                }else{
                    const token = jwt.sign({id:user.id,username:user.username},'SECRET_KEY',{expiresIn:"2h"})
                    res.json({success:true,token,username:user.username})
                }
            }
        }
    )
})



// WebSocket Handling
// WebSocket Events
    io.on("connection", (socket) => {
  console.log("New client connected:", socket.id);

  // Load previous messages from DB when a user joins
  db.query("SELECT * FROM messages ORDER BY timestamp ASC", (err, results) => {
    if (!err) {
      socket.emit("loadMessages", results);
    }
  });

  // Handle new user messages
  socket.on("message", ({ username, message }) => {
    console.log(`[Global] ${username}: ${message}`);

    // Store message in database
    db.query(
      `INSERT INTO messages (username, message, is_ai) VALUES (?, ?, false)`,
      [username, message],
      (err) => {
        if (err) console.error("Database insert failed:", err);
      }
    );

    // Send the message to everyone
    io.emit("message", { username, message, timestamp: new Date() });
  });

  socket.on("disconnect", () => {
    console.log("Client disconnected:", socket.id);
  });
});

const port =6070;
httpServer.listen(port,()=>{
    console.log(`WebSocket server running on http://localhost:${port}`);
})

