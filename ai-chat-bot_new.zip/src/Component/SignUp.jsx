import { Link } from "react-router-dom";

const Signup =({handleSignup,setPassword,setUsername,setEmail,username,email,password,handleLoginPage,signPage,loginPage})=> {

  return (
    <>

    <div className="w-full h-screen fixed flex items-center justify-center bg-[#d6358e]">
      <div className="flex flex-col items-center justify-center  bg-gray-100">
        <div className="w-96 bg-white shadow-lg rounded-lg p-6">
          <h2 className="text-2xl font-bold text-center mb-4">Sign Up</h2>
          <form onSubmit={handleSignup} className="flex flex-col">
            <input
              type="text"
              placeholder="Username"
              className="border px-3 py-2 mb-3 rounded"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            <input
              type="email"
              placeholder="Email"
              className="border px-3 py-2 mb-3 rounded"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Password"
              className="border px-3 py-2 mb-3 rounded"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button type="submit" className="bg-[#d6358e] text-white py-2 rounded">
              Sign Up
            </button>
          </form>
          <p className="text-center mt-4">
            Already have an account?{" "}
          <span onClick={handleLoginPage}> <Link to="/login" className="text-blue-500" >Login here</Link></span>
          </p>
        </div>
      </div>
    </div>
  
    </>
  );
}

export default Signup;
