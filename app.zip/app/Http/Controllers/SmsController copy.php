<?php

namespace App\Http\Controllers;

use Inertia\Inertia;
use Illuminate\Http\Request;
// use Twilio\Rest\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Twilio\TwiML\MessagingResponse;
use App\Models\UpdateModel;
use App\Events\MessageSent;
use DateTime;
use DateTimeZone;
use GuzzleHttp\Client;


class SmsController extends Controller
{
    // public function VueMessage(Request $request)
    // {

    //     try {
    //         $message = file_get_contents('php://input');
    //         $decode_message = json_decode($message, true);
    //         $message_decode = $decode_message['message'];
    //         $phoneNumber_decode = $decode_message['PhoneNumber'];
    //         // Process the message or perform any necessary actions
    //         // Send a reply back to the sender using Twilio
    //         $sid = getenv("TWILIO_ACCOUNT_SID");
    //         $token = getenv("TWILIO_AUTH_TOKEN");
    //         $twilio = new Client($sid, $token);

    //         $twilio->messages->create("whatsapp:$phoneNumber_decode", [
    //             "from" => "whatsapp:+14155238886",
    //             "body" => $message_decode
    //         ]);

    //         $timezone = new DateTimeZone('America/New_York');
    //         $now = new DateTime('now', $timezone);
    //         $currentTime = $now->format('h:i A');

    //         $newResult = new UpdateModel();
    //         $newResult->user = "1";
    //         $newResult->type = "message";
    //         $newResult->value = $message_decode;
    //         $newResult->phonnumber = $phoneNumber_decode;
    //         $newResult->time = $currentTime;
    //         $newResult->save();

    //         event(new MessageSent($newResult));

    //     } catch (\Exception $e) {
    //         return response()->json(['error' => $e->getMessage()], 500);
    //     }
    // }

    public function VueMessage(Request $request)
    {
        try {
            // Get message content from the request
            $message = file_get_contents('php://input');
            $decode_message = json_decode($message, true);
            $message_decode = $decode_message['message'];
            $phoneNumber_decode = $decode_message['PhoneNumber'];

            // Prepare data for the API request
            $accessToken = getenv('WHATSAPP_API_ACCESS_TOKEN'); // Your Meta WhatsApp API access token
            $phoneNumberId = getenv('WHATSAPP_PHONE_NUMBER_ID'); // Your WhatsApp phone number ID

            $client = new Client();
            $response = $client->post("https://graph.facebook.com/v13.0/$phoneNumberId/messages", [
                'json' => [
                    'messaging_product' => 'whatsapp',
                    'to' => $phoneNumber_decode,
                    'text' => [
                        'body' => $message_decode
                    ]
                ],
                'headers' => [
                    'Authorization' => "Bearer $accessToken",
                    'Content-Type' => 'application/json',
                ]
            ]);

            // Check if the response is successful
            if ($response->getStatusCode() === 200) {
                // Message sent successfully

                // Save the message to the database
                $timezone = new DateTimeZone('America/New_York');
                $now = new DateTime('now', $timezone);
                $currentTime = $now->format('h:i A');

                $newResult = new UpdateModel();
                $newResult->user = "1";  // Example user ID
                $newResult->type = "message";
                $newResult->value = $message_decode;
                $newResult->phonnumber = $phoneNumber_decode;
                $newResult->time = $currentTime;
                $newResult->save();

                // Trigger event (optional)
                event(new MessageSent($newResult));

                return response()->json(['message' => 'Message sent successfully'], 200);
            } else {
                // If the API request fails, handle it
                return response()->json(['error' => 'Failed to send message'], 500);
            }
        } catch (\Exception $e) {
            // Return the error response if an exception is caught
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }


    public function MediaMessage(Request $request)
    {
        try {
            if ($request->hasFile('file')) {
                // Get the uploaded file
                $file = $request->file('file');
                $extension = $file->getClientOriginalExtension();
                $fileName = time() . '_' . $file->getClientOriginalName();
                $filePath = $file->storeAs('uploads', $fileName, 'public'); // Store the file in storage

                $fileUrl = url('/storage/' . $filePath); // Generate URL to access the file

                // Determine the file type
                $type = $this->determineFileType($extension);

                // WhatsApp Business API parameters
                $accessToken = getenv('WHATSAPP_API_ACCESS_TOKEN');
                $phoneNumberId = getenv('WHATSAPP_PHONE_NUMBER_ID');

                // Upload media to WhatsApp API
                $mediaUrl = $this->uploadMediaToWhatsApp($filePath, $accessToken, $phoneNumberId);

                // Send the media URL via WhatsApp Business API
                $response = Http::withHeaders([
                    'Authorization' => "Bearer $accessToken",
                ])->post("https://graph.facebook.com/v13.0/{$phoneNumberId}/messages", [
                    'messaging_product' => 'whatsapp',
                    'to' => $request->input('PhoneNumber'),
                    'type' => 'image', // Adjust for image, video, document, etc.
                    'image' => [
                        'link' => $mediaUrl, // WhatsApp requires a URL for media
                    ],
                ]);

                $timezone = new DateTimeZone('America/New_York');
                $now = new DateTime('now', $timezone);
                $currentTime = $now->format('h:i A');

                // Save the media details into the database
                $newResult = new UpdateModel();
                $newResult->user = "1";
                $newResult->type = $type;
                $newResult->value = $fileUrl;
                $newResult->phonnumber = $request->input('PhoneNumber');
                $newResult->time = $currentTime;
                $newResult->save();

                event(new MessageSent($newResult));

                return response()->json(['message' => 'File uploaded successfully', 'fileUrl' => $fileUrl]);

            } else {
                return response()->json(['error' => 'File not provided.'], 422);
            }
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    private function uploadMediaToWhatsApp($filePath, $accessToken, $phoneNumberId)
    {
        // Upload the media to WhatsApp using their API
        $mediaUploadResponse = Http::withHeaders([
            'Authorization' => "Bearer $accessToken",
        ])->post("https://graph.facebook.com/v13.0/{$phoneNumberId}/media", [
            'url' => url('/storage/' . $filePath), // URL of the uploaded file
        ]);

        if ($mediaUploadResponse->successful()) {
            return $mediaUploadResponse->json()['url']; // Return the URL of the uploaded media
        } else {
            throw new \Exception('Failed to upload media to WhatsApp');
        }
    }

    private function determineFileType($extension)
    {
        $imageExtensions = ['png', 'jpg', 'jpeg', 'gif'];
        $videoExtensions = ['mp4', 'avi', 'mov'];
        $audioExtensions = ['mp3', 'wav', 'aac'];
        $documentExtensions = ['doc', 'docx', 'pdf', 'txt'];

        if (in_array(strtolower($extension), $imageExtensions)) {
            return 'image';
        } elseif (in_array(strtolower($extension), $videoExtensions)) {
            return 'video';
        } elseif (in_array(strtolower($extension), $audioExtensions)) {
            return 'audio';
        } elseif (in_array(strtolower($extension), $documentExtensions)) {
            return 'document';
        } else {
            return 'file';
        }
    }

    public function receiveMessage(Request $request)
    {
        try {
            // Decode incoming webhook from WhatsApp API
            $payload = json_decode($request->getContent(), true);
            $message = $payload['entry'][0]['changes'][0]['value']['messages'][0];

            // Extract phone number and message
            $phoneNumber = $message['from'];
            $body = $message['text']['body'] ?? '';
            $media = $message['image'] ?? null; // Check if media is attached

            if ($media) {
                // Handle media download
                $mediaUrl = $media['url'];
                $this->downloadAndStoreMedia($phoneNumber, $mediaUrl);
            }

            if ($body) {
                // Handle text message
                $this->saveMessage($phoneNumber, $body);
            }

            return response()->json(['message' => 'Message received']);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    private function downloadAndStoreMedia($phoneNumber, $mediaUrl)
    {
        // Download the media from WhatsApp API
        $accessToken = getenv('WHATSAPP_API_ACCESS_TOKEN');
        $response = Http::withHeaders([
            'Authorization' => "Bearer $accessToken",
        ])->get($mediaUrl);

        if ($response->successful()) {
            // Get the media content
            $content = $response->body();
            $extension = $this->getExtensionFromContentType($response->header('Content-Type'));
            $filename = 'whatsapp-media-' . time() . "." . $extension;

            // Store the media
            $path = public_path('uploads/' . $filename);
            file_put_contents($path, $content);

            $mediaUrl = asset('uploads/' . $filename);

            // Save media to database
            $newResult = new UpdateModel();
            $newResult->user = "2";
            $newResult->type = 'media';
            $newResult->value = $mediaUrl;
            $newResult->phonnumber = $phoneNumber;
            $newResult->time = now()->toDateTimeString();
            $newResult->save();

            event(new MessageSent($newResult));
        } else {
            throw new \Exception('Failed to download media from WhatsApp');
        }
    }

    private function getExtensionFromContentType($contentType)
    {
        $mimeTypes = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/gif' => 'gif',
            'image/webp' => 'webp',
            'video/mp4' => 'mp4',
            'video/avi' => 'avi',
            'video/3gpp' => '3gp',
            'video/quicktime' => 'mov',
            'audio/mpeg' => 'mp3',
            'audio/ogg' => 'ogg',
            'audio/wav' => 'wav',
            'audio/webm' => 'webm',
            'application/pdf' => 'pdf',
            'application/msword' => 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'application/vnd.ms-powerpoint' => 'ppt',
        ];

        return $mimeTypes[$contentType] ?? 'bin';
    }

    private function saveMessage($phoneNumber, $body)
    {
        $timezone = new DateTimeZone('America/New_York');
        $now = new DateTime('now', $timezone);
        $currentTime = $now->format('h:i A');

        $newResult = new UpdateModel();
        $newResult->user = "2";
        $newResult->type = 'message';
        $newResult->value = $body;
        $newResult->phonnumber = $phoneNumber;
        $newResult->time = $currentTime;
        $newResult->save();

        event(new MessageSent($newResult));
    }

}







