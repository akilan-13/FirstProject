<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\UpdateModel;
use App\Events\MessageSent;
use DateTime;
use DateTimeZone;



class WhatsAppController extends Controller
{
    public function receiveMedia(Request $request)
    {
        event(new MessageSent("Upload"));

        // Validate request data
        $validatedData = $request->validate([
            'WaId' => 'required|string|max:255',
            'Body' => 'nullable|string|max:65535',
            'NumMedia' => 'nullable|integer|min:0|max:10',
        ]);

        $phoneNumber = '+' . $validatedData['WaId'];
        $numMedia = $validatedData['NumMedia'] ?? 0;

        // Check if the message contains media
        if ($numMedia > 0) {
            for ($i = 0; $i < $numMedia; $i++) {
                $mediaUrl = $request->input("MediaUrl$i");
                $mediaContentType = $request->input("MediaContentType$i");

                // Download and store the media
                $this->downloadAndStoreMedia($mediaUrl, $i);
            }
        }

        return response()->json(['message' => 'Media processed']);
    }

    private function downloadAndStoreMedia($mediaUrl, $index)
    {
        // Get the access token and phone number ID from environment variables
        $accessToken = getenv('WHATSAPP_API_ACCESS_TOKEN');
        $phoneNumberId = getenv('WHATSAPP_PHONE_NUMBER_ID');

        // Request to get the media from the WhatsApp API
        $response = Http::withHeaders([
            'Authorization' => "Bearer $accessToken",
        ])->get($mediaUrl);

        if ($response->successful()) {
            $content = $response->body();
            $extension = $this->getExtensionFromContentType($response->header('Content-Type'));
            $filename = 'whatsapp-media-' . time() . "-{$index}." . $extension;
            $path = "D:/New/" . $filename;

            // Ensure the directory exists
            if (!file_exists(dirname($path))) {
                mkdir(dirname($path), 0777, true);
            }

            // Save the media file
            file_put_contents($path, $content);

            return $path;
        } else {
            throw new \Exception('Failed to download media from WhatsApp API');
        }
    }

    private function getExtensionFromContentType($contentType)
    {
        $mimeTypes = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'video/mp4' => 'mp4',
            // Add more MIME types and extensions as needed
        ];

        return $mimeTypes[$contentType] ?? 'bin';
    }

    public function receiveMessage(Request $request)
    {
        try {
            // Get incoming data from the request
            $message = file_get_contents('php://input');
            $decodedMessage = json_decode($message, true);

            $phoneNumber = '+' . $decodedMessage['entry'][0]['changes'][0]['value']['messages'][0]['from'];
            $body = $decodedMessage['entry'][0]['changes'][0]['value']['messages'][0]['text']['body'] ?? null;
            $media = $decodedMessage['entry'][0]['changes'][0]['value']['messages'][0]['media'] ?? null;

            // If there is a text message
            if ($body) {
                $result = $body;
                $type = 'message';
            } elseif ($media) {
                // If there is media (image, video, etc.)
                $result = $media['url'];
                $type = $this->determineMediaType($media['mime_type']);
            } else {
                // Handle unknown message types
                $result = 'Unsupported message type';
                $type = 'unknown';
            }

            // Save message/media to database
            $newResult = new UpdateModel();
            $newResult->user = "2";
            $newResult->type = $type;
            $newResult->value = $result;
            $newResult->phonnumber = $phoneNumber;
            $newResult->time = now()->toDateTimeString();
            $newResult->save();

            event(new MessageSent($newResult));

            return response()->json(['message' => 'Message processed']);
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    private function saveMedia($phoneNumber, $type, $mediaPath)
    {
        $newResult = new UpdateModel();
        $newResult->user = "2";
        $newResult->type = $type;
        $newResult->value = $mediaPath;
        $newResult->phonnumber = $phoneNumber;
        $newResult->time = now()->toDateTimeString();
        $newResult->save();

        event(new MessageSent($newResult));
    }

    private function determineMediaType($contentType)
    {
        if (strpos($contentType, 'image') !== false) {
            return 'image';
        } elseif (strpos($contentType, 'video') !== false) {
            return 'video';
        } elseif (strpos($contentType, 'audio') !== false) {
            return 'audio';
        } else {
            return 'application';
        }
    }

}
